﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp4
{
	class FoodClass
	{
		decimal TotalAmount;
		decimal InputAmount;
		const double VAT = 0.12;
		decimal TotalTotal;
		decimal VATAmount;
		decimal Change;
		string holder;
		public int[] drinksPrice = new int[] { 60, 70, 60, 85 };
		public string[] drinksName = new string[] { "Black Gulaman", "Nai Cha", "White Gulaman", "Strawbery Shake" };
		public int[] NoodlesPrice = new int[] { 145, 235, 65 };
		public string[] NoodlesName = new string[] { "Beef Noodles", "Laksa", "Hong Kong Fried Noodles" };
		public int[] ClaypotPrice = new int[] { 185, 145, 145, 165 };
		public string[] ClaypotName = new string[] { "Chicken and Sausage Combo", "Chinese Sausage w/ Mushroom", "Chicken w/ Mushroom", "Beef Brisket" };
		public int[] StrFoodPrice = new int[] { 60, 120, 38 };
		public string[] StrFoodName = new string[] { "Takoyaki", "Yakitori", "Big Isaw" };

		public FoodClass()
		{

		}
		

		public decimal Change_prop
		{
			get { return Change; }
		}
		public decimal VATAmount_prop
		{
			get { return VATAmount; }
		}
		public decimal TOTALTOTAL_prop
		{
			get { return TotalTotal; }
			set { TotalTotal = value; }
		}


		public decimal TOTALAMNT_prop
		{
			get { return TotalAmount; }
			set { TotalAmount = value; }
		}
		public decimal INPUTAMOUNT_prop
		{
			get { return InputAmount; }
			set { InputAmount = value; }
		}
		public void ComputeTOTAL(decimal n)
		{
			TotalAmount = n;
			TotalTotal = (n * (decimal)VAT) + TotalAmount;
		}
		public void ComputeVAT(decimal n)
		{
			TotalAmount = n;
			VATAmount = (n * (decimal)VAT);
		}
		public void getMoney(string a)
		{
			holder = a;
			InputAmount = Convert.ToInt32(holder);
		}
		public void getChange()
		{
			Change = InputAmount - TotalTotal;
		}

	}
}
