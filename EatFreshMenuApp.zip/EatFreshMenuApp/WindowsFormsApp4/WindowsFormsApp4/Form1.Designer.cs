﻿namespace WindowsFormsApp4
{
	partial class Form1
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
			this.button12 = new System.Windows.Forms.Button();
			this.button4 = new System.Windows.Forms.Button();
			this.button3 = new System.Windows.Forms.Button();
			this.panel1 = new System.Windows.Forms.Panel();
			this.label7 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.button5 = new System.Windows.Forms.Button();
			this.button2 = new System.Windows.Forms.Button();
			this.label3 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.button7 = new System.Windows.Forms.Button();
			this.pictureBox1 = new System.Windows.Forms.PictureBox();
			this.panel2 = new System.Windows.Forms.Panel();
			this.label4 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.button1 = new System.Windows.Forms.Button();
			this.Gulamanlabel = new System.Windows.Forms.Label();
			this.naichalabel = new System.Windows.Forms.Label();
			this.strawberrylabel = new System.Windows.Forms.Label();
			this.whitegulamanlabel = new System.Windows.Forms.Label();
			this.strawberryprice = new System.Windows.Forms.Label();
			this.naichaprice = new System.Windows.Forms.Label();
			this.whitegulamanprice = new System.Windows.Forms.Label();
			this.blackgulamanprice = new System.Windows.Forms.Label();
			this.StrawberryButton = new System.Windows.Forms.Button();
			this.WGulamanButton = new System.Windows.Forms.Button();
			this.NaiChaButton = new System.Windows.Forms.Button();
			this.BGulamanButton = new System.Windows.Forms.Button();
			this.strawberrybox = new System.Windows.Forms.PictureBox();
			this.drinkshead = new System.Windows.Forms.PictureBox();
			this.blackgulamanbox = new System.Windows.Forms.PictureBox();
			this.whitegulamanbox = new System.Windows.Forms.PictureBox();
			this.naichabox = new System.Windows.Forms.PictureBox();
			this.claypothead = new System.Windows.Forms.PictureBox();
			this.CSausageCoBox = new System.Windows.Forms.PictureBox();
			this.CWMushroomBox = new System.Windows.Forms.PictureBox();
			this.CHSausageBox = new System.Windows.Forms.PictureBox();
			this.BeefBrisketBox = new System.Windows.Forms.PictureBox();
			this.CSausageCoLabel = new System.Windows.Forms.Label();
			this.CHSausageLabel = new System.Windows.Forms.Label();
			this.CWMushroomLabel = new System.Windows.Forms.Label();
			this.BeefBrisketLabel = new System.Windows.Forms.Label();
			this.WelcomeText = new System.Windows.Forms.Label();
			this.WelcomeBox = new System.Windows.Forms.PictureBox();
			this.CSausageCoPrice = new System.Windows.Forms.Label();
			this.CWMushroomPrice = new System.Windows.Forms.Label();
			this.CHSausagePrice = new System.Windows.Forms.Label();
			this.BeefBrisketPrice = new System.Windows.Forms.Label();
			this.CSausageCoButton = new System.Windows.Forms.Button();
			this.CHSausageButton = new System.Windows.Forms.Button();
			this.BeefBrisketButton = new System.Windows.Forms.Button();
			this.CWMushroomButton = new System.Windows.Forms.Button();
			this.HKNoodlesPrice = new System.Windows.Forms.Label();
			this.LaksaPrice = new System.Windows.Forms.Label();
			this.BeefNoodlesPrice = new System.Windows.Forms.Label();
			this.NoodlesHead = new System.Windows.Forms.PictureBox();
			this.HKNoodlesText = new System.Windows.Forms.Label();
			this.BeefNoodlesText = new System.Windows.Forms.Label();
			this.LaksaText = new System.Windows.Forms.Label();
			this.BeefNoodlesLabel = new System.Windows.Forms.Label();
			this.HKNoodlesLabel = new System.Windows.Forms.Label();
			this.LaksaLabel = new System.Windows.Forms.Label();
			this.HKNoodlesBox = new System.Windows.Forms.PictureBox();
			this.LaksaBox = new System.Windows.Forms.PictureBox();
			this.BeefNoodlesBox = new System.Windows.Forms.PictureBox();
			this.BeefNoodlesButton = new System.Windows.Forms.Button();
			this.LaksaButton = new System.Windows.Forms.Button();
			this.HKNoodlesButton = new System.Windows.Forms.Button();
			this.CSausageText = new System.Windows.Forms.Label();
			this.BeefBrisketText = new System.Windows.Forms.Label();
			this.CHSausageText = new System.Windows.Forms.Label();
			this.CWMushroomText = new System.Windows.Forms.Label();
			this.BGulamanText = new System.Windows.Forms.Label();
			this.NaiChaText = new System.Windows.Forms.Label();
			this.WGulamanText = new System.Windows.Forms.Label();
			this.StrawberryText = new System.Windows.Forms.Label();
			this.BigIsawPrice = new System.Windows.Forms.Label();
			this.YakitoriPrice = new System.Windows.Forms.Label();
			this.TakoyakiPrice = new System.Windows.Forms.Label();
			this.SFhead = new System.Windows.Forms.PictureBox();
			this.BigIsawButton = new System.Windows.Forms.Button();
			this.YakitoriButton = new System.Windows.Forms.Button();
			this.TakoyakiButton = new System.Windows.Forms.Button();
			this.BigIsawText = new System.Windows.Forms.Label();
			this.YakitoriText = new System.Windows.Forms.Label();
			this.TakoyakiText = new System.Windows.Forms.Label();
			this.BigIsawLabel = new System.Windows.Forms.Label();
			this.YakitoriLabel = new System.Windows.Forms.Label();
			this.YakitoriBox = new System.Windows.Forms.PictureBox();
			this.BigIsawBox = new System.Windows.Forms.PictureBox();
			this.TakoyakiLabel = new System.Windows.Forms.Label();
			this.TakoyakiBox = new System.Windows.Forms.PictureBox();
			this.CartBox = new System.Windows.Forms.ListBox();
			this.button6 = new System.Windows.Forms.Button();
			this.button8 = new System.Windows.Forms.Button();
			this.button9 = new System.Windows.Forms.Button();
			this.Total = new System.Windows.Forms.Label();
			this.Amount = new System.Windows.Forms.Label();
			this.Finalize = new System.Windows.Forms.Button();
			this.ChangeLabel = new System.Windows.Forms.Label();
			this.NoteLabel = new System.Windows.Forms.Label();
			this.textBox1 = new System.Windows.Forms.TextBox();
			this.label8 = new System.Windows.Forms.Label();
			this.label9 = new System.Windows.Forms.Label();
			this.panel1.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
			this.panel2.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.strawberrybox)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.drinkshead)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.blackgulamanbox)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.whitegulamanbox)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.naichabox)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.claypothead)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.CSausageCoBox)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.CWMushroomBox)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.CHSausageBox)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.BeefBrisketBox)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.WelcomeBox)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.NoodlesHead)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.HKNoodlesBox)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.LaksaBox)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.BeefNoodlesBox)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.SFhead)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.YakitoriBox)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.BigIsawBox)).BeginInit();
			((System.ComponentModel.ISupportInitialize)(this.TakoyakiBox)).BeginInit();
			this.SuspendLayout();
			// 
			// button12
			// 
			this.button12.FlatAppearance.BorderSize = 0;
			this.button12.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button12.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button12.ForeColor = System.Drawing.Color.Gold;
			this.button12.Image = ((System.Drawing.Image)(resources.GetObject("button12.Image")));
			this.button12.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.button12.Location = new System.Drawing.Point(0, 357);
			this.button12.Name = "button12";
			this.button12.Size = new System.Drawing.Size(238, 66);
			this.button12.TabIndex = 11;
			this.button12.Text = "   Drinks";
			this.button12.UseVisualStyleBackColor = true;
			this.button12.Click += new System.EventHandler(this.button12_Click);
			// 
			// button4
			// 
			this.button4.FlatAppearance.BorderSize = 0;
			this.button4.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button4.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button4.ForeColor = System.Drawing.Color.Gold;
			this.button4.Image = ((System.Drawing.Image)(resources.GetObject("button4.Image")));
			this.button4.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.button4.Location = new System.Drawing.Point(0, 285);
			this.button4.Name = "button4";
			this.button4.Size = new System.Drawing.Size(238, 66);
			this.button4.TabIndex = 9;
			this.button4.Text = "        Noodles";
			this.button4.UseVisualStyleBackColor = true;
			this.button4.Click += new System.EventHandler(this.button4_Click);
			// 
			// button3
			// 
			this.button3.FlatAppearance.BorderSize = 0;
			this.button3.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button3.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button3.ForeColor = System.Drawing.Color.Gold;
			this.button3.Image = ((System.Drawing.Image)(resources.GetObject("button3.Image")));
			this.button3.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.button3.Location = new System.Drawing.Point(0, 203);
			this.button3.Name = "button3";
			this.button3.Size = new System.Drawing.Size(238, 66);
			this.button3.TabIndex = 8;
			this.button3.Text = "         Street Food";
			this.button3.UseVisualStyleBackColor = true;
			this.button3.Click += new System.EventHandler(this.button3_Click);
			// 
			// panel1
			// 
			this.panel1.BackColor = System.Drawing.Color.Firebrick;
			this.panel1.Controls.Add(this.label7);
			this.panel1.Controls.Add(this.label6);
			this.panel1.Controls.Add(this.button5);
			this.panel1.Controls.Add(this.button2);
			this.panel1.Controls.Add(this.label3);
			this.panel1.Controls.Add(this.label2);
			this.panel1.Controls.Add(this.label1);
			this.panel1.Controls.Add(this.button7);
			this.panel1.Controls.Add(this.button12);
			this.panel1.Controls.Add(this.button4);
			this.panel1.Controls.Add(this.button3);
			this.panel1.Controls.Add(this.pictureBox1);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
			this.panel1.Location = new System.Drawing.Point(0, 0);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(241, 613);
			this.panel1.TabIndex = 2;
			// 
			// label7
			// 
			this.label7.AutoSize = true;
			this.label7.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label7.ForeColor = System.Drawing.Color.Gold;
			this.label7.Location = new System.Drawing.Point(27, 540);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(75, 34);
			this.label7.TabIndex = 16;
			this.label7.Text = "02 5168022\r\n02 4750789";
			// 
			// label6
			// 
			this.label6.AutoSize = true;
			this.label6.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label6.ForeColor = System.Drawing.Color.Gold;
			this.label6.Location = new System.Drawing.Point(27, 503);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(164, 32);
			this.label6.TabIndex = 15;
			this.label6.Text = "100-A Maria Clara Street,\r\nSanto Domingo, Quezon City";
			// 
			// button5
			// 
			this.button5.BackColor = System.Drawing.Color.DarkGreen;
			this.button5.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button5.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button5.ForeColor = System.Drawing.Color.DarkGray;
			this.button5.Location = new System.Drawing.Point(129, 452);
			this.button5.Name = "button5";
			this.button5.Size = new System.Drawing.Size(84, 36);
			this.button5.TabIndex = 14;
			this.button5.Text = "Finalize";
			this.button5.UseVisualStyleBackColor = false;
			this.button5.Click += new System.EventHandler(this.button5_Click);
			// 
			// button2
			// 
			this.button2.BackColor = System.Drawing.Color.DarkGreen;
			this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button2.ForeColor = System.Drawing.Color.DarkGray;
			this.button2.Location = new System.Drawing.Point(30, 452);
			this.button2.Name = "button2";
			this.button2.Size = new System.Drawing.Size(84, 36);
			this.button2.TabIndex = 6;
			this.button2.Text = "View Cart";
			this.button2.UseVisualStyleBackColor = false;
			this.button2.Click += new System.EventHandler(this.button2_Click);
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label3.ForeColor = System.Drawing.Color.Gold;
			this.label3.Location = new System.Drawing.Point(105, 50);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(135, 17);
			this.label3.TabIndex = 13;
			this.label3.Text = "Famous Street Food";
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label2.ForeColor = System.Drawing.Color.Gold;
			this.label2.Location = new System.Drawing.Point(105, 33);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(81, 17);
			this.label2.TabIndex = 12;
			this.label2.Text = "Hong Kong";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label1.ForeColor = System.Drawing.Color.Gold;
			this.label1.Location = new System.Drawing.Point(105, 16);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(69, 17);
			this.label1.TabIndex = 2;
			this.label1.Text = "EAT FRESH";
			// 
			// button7
			// 
			this.button7.BackColor = System.Drawing.Color.Firebrick;
			this.button7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
			this.button7.FlatAppearance.BorderSize = 0;
			this.button7.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button7.Font = new System.Drawing.Font("Century Gothic", 20.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.button7.ForeColor = System.Drawing.Color.Gold;
			this.button7.Image = ((System.Drawing.Image)(resources.GetObject("button7.Image")));
			this.button7.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
			this.button7.Location = new System.Drawing.Point(0, 131);
			this.button7.Name = "button7";
			this.button7.Size = new System.Drawing.Size(238, 66);
			this.button7.TabIndex = 6;
			this.button7.Text = "        Clay Pot";
			this.button7.UseVisualStyleBackColor = false;
			this.button7.Click += new System.EventHandler(this.button7_Click);
			// 
			// pictureBox1
			// 
			this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
			this.pictureBox1.Location = new System.Drawing.Point(12, 12);
			this.pictureBox1.Name = "pictureBox1";
			this.pictureBox1.Size = new System.Drawing.Size(87, 84);
			this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.pictureBox1.TabIndex = 1;
			this.pictureBox1.TabStop = false;
			// 
			// panel2
			// 
			this.panel2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(249)))), ((int)(((byte)(241)))), ((int)(((byte)(104)))));
			this.panel2.Controls.Add(this.label4);
			this.panel2.Controls.Add(this.label5);
			this.panel2.Controls.Add(this.button1);
			this.panel2.Location = new System.Drawing.Point(241, 0);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(859, 33);
			this.panel2.TabIndex = 4;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label4.ForeColor = System.Drawing.Color.DarkGreen;
			this.label4.Location = new System.Drawing.Point(637, 8);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(45, 17);
			this.label4.TabIndex = 8;
			this.label4.Text = "label4";
			// 
			// label5
			// 
			this.label5.AutoSize = true;
			this.label5.Font = new System.Drawing.Font("Century Gothic", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label5.ForeColor = System.Drawing.Color.DarkGreen;
			this.label5.Location = new System.Drawing.Point(476, 8);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(45, 17);
			this.label5.TabIndex = 7;
			this.label5.Text = "label5";
			// 
			// button1
			// 
			this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.button1.ForeColor = System.Drawing.Color.DarkGreen;
			this.button1.Location = new System.Drawing.Point(788, 3);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(56, 27);
			this.button1.TabIndex = 5;
			this.button1.Text = "Close";
			this.button1.UseVisualStyleBackColor = true;
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// Gulamanlabel
			// 
			this.Gulamanlabel.AutoSize = true;
			this.Gulamanlabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
			this.Gulamanlabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.Gulamanlabel.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Gulamanlabel.Location = new System.Drawing.Point(376, 330);
			this.Gulamanlabel.Name = "Gulamanlabel";
			this.Gulamanlabel.Size = new System.Drawing.Size(91, 16);
			this.Gulamanlabel.TabIndex = 69;
			this.Gulamanlabel.Text = "Black Gulaman";
			// 
			// naichalabel
			// 
			this.naichalabel.AutoSize = true;
			this.naichalabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
			this.naichalabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.naichalabel.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.naichalabel.Location = new System.Drawing.Point(620, 330);
			this.naichalabel.Name = "naichalabel";
			this.naichalabel.Size = new System.Drawing.Size(53, 16);
			this.naichalabel.TabIndex = 68;
			this.naichalabel.Text = "Nai Cha";
			// 
			// strawberrylabel
			// 
			this.strawberrylabel.AutoSize = true;
			this.strawberrylabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
			this.strawberrylabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.strawberrylabel.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.strawberrylabel.Location = new System.Drawing.Point(996, 314);
			this.strawberrylabel.Name = "strawberrylabel";
			this.strawberrylabel.Size = new System.Drawing.Size(69, 32);
			this.strawberrylabel.TabIndex = 67;
			this.strawberrylabel.Text = "Strawberry \r\n        Shake";
			// 
			// whitegulamanlabel
			// 
			this.whitegulamanlabel.AutoSize = true;
			this.whitegulamanlabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
			this.whitegulamanlabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.whitegulamanlabel.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.whitegulamanlabel.Location = new System.Drawing.Point(786, 330);
			this.whitegulamanlabel.Name = "whitegulamanlabel";
			this.whitegulamanlabel.Size = new System.Drawing.Size(94, 16);
			this.whitegulamanlabel.TabIndex = 66;
			this.whitegulamanlabel.Text = "White Gulaman";
			// 
			// strawberryprice
			// 
			this.strawberryprice.AutoSize = true;
			this.strawberryprice.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.strawberryprice.Location = new System.Drawing.Point(983, 461);
			this.strawberryprice.Name = "strawberryprice";
			this.strawberryprice.Size = new System.Drawing.Size(37, 13);
			this.strawberryprice.TabIndex = 65;
			this.strawberryprice.Text = "₱  85";
			// 
			// naichaprice
			// 
			this.naichaprice.AutoSize = true;
			this.naichaprice.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.naichaprice.Location = new System.Drawing.Point(561, 461);
			this.naichaprice.Name = "naichaprice";
			this.naichaprice.Size = new System.Drawing.Size(37, 13);
			this.naichaprice.TabIndex = 64;
			this.naichaprice.Text = "₱  70";
			// 
			// whitegulamanprice
			// 
			this.whitegulamanprice.AutoSize = true;
			this.whitegulamanprice.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.whitegulamanprice.Location = new System.Drawing.Point(770, 461);
			this.whitegulamanprice.Name = "whitegulamanprice";
			this.whitegulamanprice.Size = new System.Drawing.Size(37, 13);
			this.whitegulamanprice.TabIndex = 63;
			this.whitegulamanprice.Text = "₱  60";
			// 
			// blackgulamanprice
			// 
			this.blackgulamanprice.AutoSize = true;
			this.blackgulamanprice.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.blackgulamanprice.Location = new System.Drawing.Point(356, 465);
			this.blackgulamanprice.Name = "blackgulamanprice";
			this.blackgulamanprice.Size = new System.Drawing.Size(37, 13);
			this.blackgulamanprice.TabIndex = 62;
			this.blackgulamanprice.Text = "₱  60";
			// 
			// StrawberryButton
			// 
			this.StrawberryButton.Location = new System.Drawing.Point(942, 492);
			this.StrawberryButton.Name = "StrawberryButton";
			this.StrawberryButton.Size = new System.Drawing.Size(112, 34);
			this.StrawberryButton.TabIndex = 61;
			this.StrawberryButton.Text = "Add To Cart";
			this.StrawberryButton.UseVisualStyleBackColor = true;
			this.StrawberryButton.Click += new System.EventHandler(this.StrawberryButton_Click);
			// 
			// WGulamanButton
			// 
			this.WGulamanButton.Location = new System.Drawing.Point(738, 492);
			this.WGulamanButton.Name = "WGulamanButton";
			this.WGulamanButton.Size = new System.Drawing.Size(112, 34);
			this.WGulamanButton.TabIndex = 60;
			this.WGulamanButton.Text = "Add To Cart";
			this.WGulamanButton.UseVisualStyleBackColor = true;
			this.WGulamanButton.Click += new System.EventHandler(this.WGulamanButton_Click);
			// 
			// NaiChaButton
			// 
			this.NaiChaButton.Location = new System.Drawing.Point(519, 492);
			this.NaiChaButton.Name = "NaiChaButton";
			this.NaiChaButton.Size = new System.Drawing.Size(112, 34);
			this.NaiChaButton.TabIndex = 59;
			this.NaiChaButton.Text = "Add To Cart";
			this.NaiChaButton.UseVisualStyleBackColor = true;
			this.NaiChaButton.Click += new System.EventHandler(this.NaiChaButton_Click);
			// 
			// BGulamanButton
			// 
			this.BGulamanButton.Location = new System.Drawing.Point(323, 492);
			this.BGulamanButton.Name = "BGulamanButton";
			this.BGulamanButton.Size = new System.Drawing.Size(112, 34);
			this.BGulamanButton.TabIndex = 58;
			this.BGulamanButton.Text = "Add To Cart";
			this.BGulamanButton.UseVisualStyleBackColor = true;
			this.BGulamanButton.Click += new System.EventHandler(this.BGulamanButton_Click);
			// 
			// strawberrybox
			// 
			this.strawberrybox.Image = ((System.Drawing.Image)(resources.GetObject("strawberrybox.Image")));
			this.strawberrybox.Location = new System.Drawing.Point(919, 194);
			this.strawberrybox.Name = "strawberrybox";
			this.strawberrybox.Size = new System.Drawing.Size(146, 169);
			this.strawberrybox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.strawberrybox.TabIndex = 57;
			this.strawberrybox.TabStop = false;
			// 
			// drinkshead
			// 
			this.drinkshead.Image = ((System.Drawing.Image)(resources.GetObject("drinkshead.Image")));
			this.drinkshead.Location = new System.Drawing.Point(366, 50);
			this.drinkshead.Name = "drinkshead";
			this.drinkshead.Size = new System.Drawing.Size(635, 96);
			this.drinkshead.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.drinkshead.TabIndex = 56;
			this.drinkshead.TabStop = false;
			// 
			// blackgulamanbox
			// 
			this.blackgulamanbox.Image = ((System.Drawing.Image)(resources.GetObject("blackgulamanbox.Image")));
			this.blackgulamanbox.Location = new System.Drawing.Point(275, 194);
			this.blackgulamanbox.Name = "blackgulamanbox";
			this.blackgulamanbox.Size = new System.Drawing.Size(192, 169);
			this.blackgulamanbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.blackgulamanbox.TabIndex = 55;
			this.blackgulamanbox.TabStop = false;
			// 
			// whitegulamanbox
			// 
			this.whitegulamanbox.Image = ((System.Drawing.Image)(resources.GetObject("whitegulamanbox.Image")));
			this.whitegulamanbox.Location = new System.Drawing.Point(694, 194);
			this.whitegulamanbox.Name = "whitegulamanbox";
			this.whitegulamanbox.Size = new System.Drawing.Size(202, 169);
			this.whitegulamanbox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.whitegulamanbox.TabIndex = 54;
			this.whitegulamanbox.TabStop = false;
			// 
			// naichabox
			// 
			this.naichabox.Image = ((System.Drawing.Image)(resources.GetObject("naichabox.Image")));
			this.naichabox.Location = new System.Drawing.Point(501, 194);
			this.naichabox.Name = "naichabox";
			this.naichabox.Size = new System.Drawing.Size(172, 169);
			this.naichabox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.naichabox.TabIndex = 53;
			this.naichabox.TabStop = false;
			// 
			// claypothead
			// 
			this.claypothead.Image = ((System.Drawing.Image)(resources.GetObject("claypothead.Image")));
			this.claypothead.Location = new System.Drawing.Point(369, 50);
			this.claypothead.Name = "claypothead";
			this.claypothead.Size = new System.Drawing.Size(635, 96);
			this.claypothead.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.claypothead.TabIndex = 70;
			this.claypothead.TabStop = false;
			// 
			// CSausageCoBox
			// 
			this.CSausageCoBox.Image = ((System.Drawing.Image)(resources.GetObject("CSausageCoBox.Image")));
			this.CSausageCoBox.Location = new System.Drawing.Point(275, 177);
			this.CSausageCoBox.Name = "CSausageCoBox";
			this.CSausageCoBox.Size = new System.Drawing.Size(173, 169);
			this.CSausageCoBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.CSausageCoBox.TabIndex = 71;
			this.CSausageCoBox.TabStop = false;
			// 
			// CWMushroomBox
			// 
			this.CWMushroomBox.Image = ((System.Drawing.Image)(resources.GetObject("CWMushroomBox.Image")));
			this.CWMushroomBox.Location = new System.Drawing.Point(287, 416);
			this.CWMushroomBox.Name = "CWMushroomBox";
			this.CWMushroomBox.Size = new System.Drawing.Size(167, 156);
			this.CWMushroomBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.CWMushroomBox.TabIndex = 72;
			this.CWMushroomBox.TabStop = false;
			// 
			// CHSausageBox
			// 
			this.CHSausageBox.Image = ((System.Drawing.Image)(resources.GetObject("CHSausageBox.Image")));
			this.CHSausageBox.Location = new System.Drawing.Point(720, 177);
			this.CHSausageBox.Name = "CHSausageBox";
			this.CHSausageBox.Size = new System.Drawing.Size(160, 169);
			this.CHSausageBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.CHSausageBox.TabIndex = 73;
			this.CHSausageBox.TabStop = false;
			// 
			// BeefBrisketBox
			// 
			this.BeefBrisketBox.Image = ((System.Drawing.Image)(resources.GetObject("BeefBrisketBox.Image")));
			this.BeefBrisketBox.Location = new System.Drawing.Point(720, 416);
			this.BeefBrisketBox.Name = "BeefBrisketBox";
			this.BeefBrisketBox.Size = new System.Drawing.Size(160, 153);
			this.BeefBrisketBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
			this.BeefBrisketBox.TabIndex = 74;
			this.BeefBrisketBox.TabStop = false;
			// 
			// CSausageCoLabel
			// 
			this.CSausageCoLabel.AutoSize = true;
			this.CSausageCoLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
			this.CSausageCoLabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.CSausageCoLabel.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.CSausageCoLabel.Location = new System.Drawing.Point(320, 298);
			this.CSausageCoLabel.Name = "CSausageCoLabel";
			this.CSausageCoLabel.Size = new System.Drawing.Size(128, 32);
			this.CSausageCoLabel.TabIndex = 75;
			this.CSausageCoLabel.Text = "Chicken and Sausage\r\n                      Combo";
			// 
			// CHSausageLabel
			// 
			this.CHSausageLabel.AutoSize = true;
			this.CHSausageLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
			this.CHSausageLabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.CHSausageLabel.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.CHSausageLabel.Location = new System.Drawing.Point(779, 298);
			this.CHSausageLabel.Name = "CHSausageLabel";
			this.CHSausageLabel.Size = new System.Drawing.Size(101, 32);
			this.CHSausageLabel.TabIndex = 76;
			this.CHSausageLabel.Text = "Chinese Sausage\r\n with Mushroom";
			// 
			// CWMushroomLabel
			// 
			this.CWMushroomLabel.AutoSize = true;
			this.CWMushroomLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
			this.CWMushroomLabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.CWMushroomLabel.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.CWMushroomLabel.Location = new System.Drawing.Point(376, 524);
			this.CWMushroomLabel.Name = "CWMushroomLabel";
			this.CWMushroomLabel.Size = new System.Drawing.Size(78, 32);
			this.CWMushroomLabel.TabIndex = 77;
			this.CWMushroomLabel.Text = "Chicken with\r\n   Mushroom";
			// 
			// BeefBrisketLabel
			// 
			this.BeefBrisketLabel.AutoSize = true;
			this.BeefBrisketLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
			this.BeefBrisketLabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.BeefBrisketLabel.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.BeefBrisketLabel.Location = new System.Drawing.Point(815, 540);
			this.BeefBrisketLabel.Name = "BeefBrisketLabel";
			this.BeefBrisketLabel.Size = new System.Drawing.Size(65, 16);
			this.BeefBrisketLabel.TabIndex = 78;
			this.BeefBrisketLabel.Text = "Beef Brisket";
			// 
			// WelcomeText
			// 
			this.WelcomeText.AutoSize = true;
			this.WelcomeText.BackColor = System.Drawing.Color.White;
			this.WelcomeText.Font = new System.Drawing.Font("Century Gothic", 27.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.WelcomeText.ForeColor = System.Drawing.Color.Sienna;
			this.WelcomeText.Location = new System.Drawing.Point(570, 243);
			this.WelcomeText.Name = "WelcomeText";
			this.WelcomeText.Size = new System.Drawing.Size(203, 44);
			this.WelcomeText.TabIndex = 80;
			this.WelcomeText.Text = "Welcome!";
			// 
			// WelcomeBox
			// 
			this.WelcomeBox.Image = ((System.Drawing.Image)(resources.GetObject("WelcomeBox.Image")));
			this.WelcomeBox.Location = new System.Drawing.Point(241, 67);
			this.WelcomeBox.Name = "WelcomeBox";
			this.WelcomeBox.Size = new System.Drawing.Size(844, 481);
			this.WelcomeBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.WelcomeBox.TabIndex = 79;
			this.WelcomeBox.TabStop = false;
			// 
			// CSausageCoPrice
			// 
			this.CSausageCoPrice.AutoSize = true;
			this.CSausageCoPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.CSausageCoPrice.Location = new System.Drawing.Point(551, 287);
			this.CSausageCoPrice.Name = "CSausageCoPrice";
			this.CSausageCoPrice.Size = new System.Drawing.Size(44, 13);
			this.CSausageCoPrice.TabIndex = 81;
			this.CSausageCoPrice.Text = "₱  185";
			// 
			// CWMushroomPrice
			// 
			this.CWMushroomPrice.AutoSize = true;
			this.CWMushroomPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.CWMushroomPrice.Location = new System.Drawing.Point(551, 503);
			this.CWMushroomPrice.Name = "CWMushroomPrice";
			this.CWMushroomPrice.Size = new System.Drawing.Size(44, 13);
			this.CWMushroomPrice.TabIndex = 82;
			this.CWMushroomPrice.Text = "₱  145";
			// 
			// CHSausagePrice
			// 
			this.CHSausagePrice.AutoSize = true;
			this.CHSausagePrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.CHSausagePrice.Location = new System.Drawing.Point(964, 287);
			this.CHSausagePrice.Name = "CHSausagePrice";
			this.CHSausagePrice.Size = new System.Drawing.Size(40, 13);
			this.CHSausagePrice.TabIndex = 83;
			this.CHSausagePrice.Text = "₱ 145";
			// 
			// BeefBrisketPrice
			// 
			this.BeefBrisketPrice.AutoSize = true;
			this.BeefBrisketPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.BeefBrisketPrice.Location = new System.Drawing.Point(964, 503);
			this.BeefBrisketPrice.Name = "BeefBrisketPrice";
			this.BeefBrisketPrice.Size = new System.Drawing.Size(44, 13);
			this.BeefBrisketPrice.TabIndex = 84;
			this.BeefBrisketPrice.Text = "₱  165";
			// 
			// CSausageCoButton
			// 
			this.CSausageCoButton.Location = new System.Drawing.Point(519, 308);
			this.CSausageCoButton.Name = "CSausageCoButton";
			this.CSausageCoButton.Size = new System.Drawing.Size(112, 34);
			this.CSausageCoButton.TabIndex = 85;
			this.CSausageCoButton.Text = "Add To Cart";
			this.CSausageCoButton.UseVisualStyleBackColor = true;
			this.CSausageCoButton.Click += new System.EventHandler(this.CSausageCoButton_Click);
			// 
			// CHSausageButton
			// 
			this.CHSausageButton.Location = new System.Drawing.Point(934, 308);
			this.CHSausageButton.Name = "CHSausageButton";
			this.CHSausageButton.Size = new System.Drawing.Size(112, 34);
			this.CHSausageButton.TabIndex = 86;
			this.CHSausageButton.Text = "Add To Cart";
			this.CHSausageButton.UseVisualStyleBackColor = true;
			this.CHSausageButton.Click += new System.EventHandler(this.CHSausageButton_Click);
			// 
			// BeefBrisketButton
			// 
			this.BeefBrisketButton.Location = new System.Drawing.Point(934, 530);
			this.BeefBrisketButton.Name = "BeefBrisketButton";
			this.BeefBrisketButton.Size = new System.Drawing.Size(112, 34);
			this.BeefBrisketButton.TabIndex = 87;
			this.BeefBrisketButton.Text = "Add To Cart";
			this.BeefBrisketButton.UseVisualStyleBackColor = true;
			this.BeefBrisketButton.Click += new System.EventHandler(this.BeefBrisketButton_Click);
			// 
			// CWMushroomButton
			// 
			this.CWMushroomButton.Location = new System.Drawing.Point(519, 530);
			this.CWMushroomButton.Name = "CWMushroomButton";
			this.CWMushroomButton.Size = new System.Drawing.Size(112, 34);
			this.CWMushroomButton.TabIndex = 88;
			this.CWMushroomButton.Text = "Add To Cart";
			this.CWMushroomButton.UseVisualStyleBackColor = true;
			this.CWMushroomButton.Click += new System.EventHandler(this.CWMushroomButton_Click);
			// 
			// HKNoodlesPrice
			// 
			this.HKNoodlesPrice.AutoSize = true;
			this.HKNoodlesPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.HKNoodlesPrice.Location = new System.Drawing.Point(944, 491);
			this.HKNoodlesPrice.Name = "HKNoodlesPrice";
			this.HKNoodlesPrice.Size = new System.Drawing.Size(37, 13);
			this.HKNoodlesPrice.TabIndex = 136;
			this.HKNoodlesPrice.Text = "₱  65";
			// 
			// LaksaPrice
			// 
			this.LaksaPrice.AutoSize = true;
			this.LaksaPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.LaksaPrice.Location = new System.Drawing.Point(659, 491);
			this.LaksaPrice.Name = "LaksaPrice";
			this.LaksaPrice.Size = new System.Drawing.Size(44, 13);
			this.LaksaPrice.TabIndex = 135;
			this.LaksaPrice.Text = "₱  235";
			// 
			// BeefNoodlesPrice
			// 
			this.BeefNoodlesPrice.AutoSize = true;
			this.BeefNoodlesPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.BeefNoodlesPrice.Location = new System.Drawing.Point(393, 491);
			this.BeefNoodlesPrice.Name = "BeefNoodlesPrice";
			this.BeefNoodlesPrice.Size = new System.Drawing.Size(44, 13);
			this.BeefNoodlesPrice.TabIndex = 134;
			this.BeefNoodlesPrice.Text = "₱  145";
			// 
			// NoodlesHead
			// 
			this.NoodlesHead.Image = ((System.Drawing.Image)(resources.GetObject("NoodlesHead.Image")));
			this.NoodlesHead.Location = new System.Drawing.Point(366, 50);
			this.NoodlesHead.Name = "NoodlesHead";
			this.NoodlesHead.Size = new System.Drawing.Size(635, 96);
			this.NoodlesHead.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.NoodlesHead.TabIndex = 133;
			this.NoodlesHead.TabStop = false;
			// 
			// HKNoodlesText
			// 
			this.HKNoodlesText.AutoSize = true;
			this.HKNoodlesText.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.HKNoodlesText.Location = new System.Drawing.Point(887, 427);
			this.HKNoodlesText.Name = "HKNoodlesText";
			this.HKNoodlesText.Size = new System.Drawing.Size(178, 51);
			this.HKNoodlesText.TabIndex = 132;
			this.HKNoodlesText.Text = "Healthy Asian stir-fried\r\nnoodles with fresh veggies\r\nand sesame oil";
			// 
			// BeefNoodlesText
			// 
			this.BeefNoodlesText.AutoSize = true;
			this.BeefNoodlesText.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.BeefNoodlesText.Location = new System.Drawing.Point(325, 427);
			this.BeefNoodlesText.Name = "BeefNoodlesText";
			this.BeefNoodlesText.Size = new System.Drawing.Size(194, 51);
			this.BeefNoodlesText.TabIndex = 131;
			this.BeefNoodlesText.Text = "Tender beef, fresh veggies, \r\nand noodles tossed together\r\n in a delicious savory" +
    " sauce";
			// 
			// LaksaText
			// 
			this.LaksaText.AutoSize = true;
			this.LaksaText.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.LaksaText.Location = new System.Drawing.Point(604, 427);
			this.LaksaText.Name = "LaksaText";
			this.LaksaText.Size = new System.Drawing.Size(176, 51);
			this.LaksaText.TabIndex = 130;
			this.LaksaText.Text = "prawn or fish noodle soup\r\nserved in spicy soup with\r\nrich curry coconut milk";
			// 
			// BeefNoodlesLabel
			// 
			this.BeefNoodlesLabel.AutoSize = true;
			this.BeefNoodlesLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
			this.BeefNoodlesLabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.BeefNoodlesLabel.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.BeefNoodlesLabel.Location = new System.Drawing.Point(431, 366);
			this.BeefNoodlesLabel.Name = "BeefNoodlesLabel";
			this.BeefNoodlesLabel.Size = new System.Drawing.Size(77, 16);
			this.BeefNoodlesLabel.TabIndex = 126;
			this.BeefNoodlesLabel.Text = "Beef Noodles";
			// 
			// HKNoodlesLabel
			// 
			this.HKNoodlesLabel.AutoSize = true;
			this.HKNoodlesLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
			this.HKNoodlesLabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.HKNoodlesLabel.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.HKNoodlesLabel.Location = new System.Drawing.Point(964, 369);
			this.HKNoodlesLabel.Name = "HKNoodlesLabel";
			this.HKNoodlesLabel.Size = new System.Drawing.Size(96, 32);
			this.HKNoodlesLabel.TabIndex = 125;
			this.HKNoodlesLabel.Text = "Hong Kong Fried\r\n               Noodles";
			// 
			// LaksaLabel
			// 
			this.LaksaLabel.AutoSize = true;
			this.LaksaLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
			this.LaksaLabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.LaksaLabel.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.LaksaLabel.Location = new System.Drawing.Point(735, 369);
			this.LaksaLabel.Name = "LaksaLabel";
			this.LaksaLabel.Size = new System.Drawing.Size(38, 16);
			this.LaksaLabel.TabIndex = 124;
			this.LaksaLabel.Text = "Laksa";
			// 
			// HKNoodlesBox
			// 
			this.HKNoodlesBox.Image = ((System.Drawing.Image)(resources.GetObject("HKNoodlesBox.Image")));
			this.HKNoodlesBox.Location = new System.Drawing.Point(863, 227);
			this.HKNoodlesBox.Name = "HKNoodlesBox";
			this.HKNoodlesBox.Size = new System.Drawing.Size(202, 181);
			this.HKNoodlesBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.HKNoodlesBox.TabIndex = 123;
			this.HKNoodlesBox.TabStop = false;
			// 
			// LaksaBox
			// 
			this.LaksaBox.Image = ((System.Drawing.Image)(resources.GetObject("LaksaBox.Image")));
			this.LaksaBox.Location = new System.Drawing.Point(595, 224);
			this.LaksaBox.Name = "LaksaBox";
			this.LaksaBox.Size = new System.Drawing.Size(194, 184);
			this.LaksaBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.LaksaBox.TabIndex = 122;
			this.LaksaBox.TabStop = false;
			// 
			// BeefNoodlesBox
			// 
			this.BeefNoodlesBox.Image = ((System.Drawing.Image)(resources.GetObject("BeefNoodlesBox.Image")));
			this.BeefNoodlesBox.Location = new System.Drawing.Point(328, 227);
			this.BeefNoodlesBox.Name = "BeefNoodlesBox";
			this.BeefNoodlesBox.Size = new System.Drawing.Size(190, 172);
			this.BeefNoodlesBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.BeefNoodlesBox.TabIndex = 121;
			this.BeefNoodlesBox.TabStop = false;
			// 
			// BeefNoodlesButton
			// 
			this.BeefNoodlesButton.Location = new System.Drawing.Point(366, 520);
			this.BeefNoodlesButton.Name = "BeefNoodlesButton";
			this.BeefNoodlesButton.Size = new System.Drawing.Size(112, 34);
			this.BeefNoodlesButton.TabIndex = 137;
			this.BeefNoodlesButton.Text = "Add To Cart";
			this.BeefNoodlesButton.UseVisualStyleBackColor = true;
			this.BeefNoodlesButton.Click += new System.EventHandler(this.BeefNoodlesButton_Click);
			// 
			// LaksaButton
			// 
			this.LaksaButton.Location = new System.Drawing.Point(628, 520);
			this.LaksaButton.Name = "LaksaButton";
			this.LaksaButton.Size = new System.Drawing.Size(112, 34);
			this.LaksaButton.TabIndex = 138;
			this.LaksaButton.Text = "Add To Cart";
			this.LaksaButton.UseVisualStyleBackColor = true;
			this.LaksaButton.Click += new System.EventHandler(this.LaksaButton_Click);
			// 
			// HKNoodlesButton
			// 
			this.HKNoodlesButton.Location = new System.Drawing.Point(918, 520);
			this.HKNoodlesButton.Name = "HKNoodlesButton";
			this.HKNoodlesButton.Size = new System.Drawing.Size(112, 34);
			this.HKNoodlesButton.TabIndex = 139;
			this.HKNoodlesButton.Text = "Add To Cart";
			this.HKNoodlesButton.UseVisualStyleBackColor = true;
			this.HKNoodlesButton.Click += new System.EventHandler(this.HKNoodlesButton_Click);
			// 
			// CSausageText
			// 
			this.CSausageText.AutoSize = true;
			this.CSausageText.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.CSausageText.Location = new System.Drawing.Point(495, 218);
			this.CSausageText.Name = "CSausageText";
			this.CSausageText.Size = new System.Drawing.Size(178, 51);
			this.CSausageText.TabIndex = 140;
			this.CSausageText.Text = "Chinese steamed chicken \r\nand chinese sausage with\r\nginger rice";
			// 
			// BeefBrisketText
			// 
			this.BeefBrisketText.AutoSize = true;
			this.BeefBrisketText.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.BeefBrisketText.Location = new System.Drawing.Point(897, 437);
			this.BeefBrisketText.Name = "BeefBrisketText";
			this.BeefBrisketText.Size = new System.Drawing.Size(180, 51);
			this.BeefBrisketText.TabIndex = 141;
			this.BeefBrisketText.Text = "Tender, juicy, flavour \r\nBeef Brisket smothered\r\nin a HongKong Style Sauce";
			// 
			// CHSausageText
			// 
			this.CHSausageText.AutoSize = true;
			this.CHSausageText.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.CHSausageText.Location = new System.Drawing.Point(930, 218);
			this.CHSausageText.Name = "CHSausageText";
			this.CHSausageText.Size = new System.Drawing.Size(116, 51);
			this.CHSausageText.TabIndex = 142;
			this.CHSausageText.Text = "Chinese sausage\r\n and mushrooms\r\n in teriyaki sauce";
			// 
			// CWMushroomText
			// 
			this.CWMushroomText.AutoSize = true;
			this.CWMushroomText.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.CWMushroomText.Location = new System.Drawing.Point(481, 432);
			this.CWMushroomText.Name = "CWMushroomText";
			this.CWMushroomText.Size = new System.Drawing.Size(202, 51);
			this.CWMushroomText.TabIndex = 143;
			this.CWMushroomText.Text = "Chinese steamed chicken\r\nand mushrooms paired with\r\nsweet tangy mushroom sauce";
			// 
			// BGulamanText
			// 
			this.BGulamanText.AutoSize = true;
			this.BGulamanText.BackColor = System.Drawing.SystemColors.Control;
			this.BGulamanText.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.BGulamanText.Location = new System.Drawing.Point(305, 402);
			this.BGulamanText.Name = "BGulamanText";
			this.BGulamanText.Size = new System.Drawing.Size(136, 34);
			this.BGulamanText.TabIndex = 144;
			this.BGulamanText.Text = "Brown sugar water\r\nwith cube grass jelly";
			// 
			// NaiChaText
			// 
			this.NaiChaText.AutoSize = true;
			this.NaiChaText.BackColor = System.Drawing.SystemColors.Control;
			this.NaiChaText.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.NaiChaText.Location = new System.Drawing.Point(505, 402);
			this.NaiChaText.Name = "NaiChaText";
			this.NaiChaText.Size = new System.Drawing.Size(168, 51);
			this.NaiChaText.TabIndex = 145;
			this.NaiChaText.Text = "Hong Kong style milk tea\r\nstirred in sweetened and\r\ncondensed milk";
			// 
			// WGulamanText
			// 
			this.WGulamanText.AutoSize = true;
			this.WGulamanText.BackColor = System.Drawing.SystemColors.Control;
			this.WGulamanText.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.WGulamanText.Location = new System.Drawing.Point(735, 402);
			this.WGulamanText.Name = "WGulamanText";
			this.WGulamanText.Size = new System.Drawing.Size(123, 34);
			this.WGulamanText.TabIndex = 146;
			this.WGulamanText.Text = "Sugar water with\r\ncube almond jelly";
			// 
			// StrawberryText
			// 
			this.StrawberryText.AutoSize = true;
			this.StrawberryText.BackColor = System.Drawing.SystemColors.Control;
			this.StrawberryText.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.StrawberryText.Location = new System.Drawing.Point(923, 401);
			this.StrawberryText.Name = "StrawberryText";
			this.StrawberryText.Size = new System.Drawing.Size(142, 51);
			this.StrawberryText.TabIndex = 147;
			this.StrawberryText.Text = "freshly blended pure \r\nstrawberriestopped \r\nwith strawberry syrup";
			// 
			// BigIsawPrice
			// 
			this.BigIsawPrice.AutoSize = true;
			this.BigIsawPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.BigIsawPrice.Location = new System.Drawing.Point(952, 489);
			this.BigIsawPrice.Name = "BigIsawPrice";
			this.BigIsawPrice.Size = new System.Drawing.Size(37, 13);
			this.BigIsawPrice.TabIndex = 163;
			this.BigIsawPrice.Text = "₱  38";
			// 
			// YakitoriPrice
			// 
			this.YakitoriPrice.AutoSize = true;
			this.YakitoriPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.YakitoriPrice.Location = new System.Drawing.Point(658, 489);
			this.YakitoriPrice.Name = "YakitoriPrice";
			this.YakitoriPrice.Size = new System.Drawing.Size(44, 13);
			this.YakitoriPrice.TabIndex = 162;
			this.YakitoriPrice.Text = "₱  120";
			// 
			// TakoyakiPrice
			// 
			this.TakoyakiPrice.AutoSize = true;
			this.TakoyakiPrice.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.TakoyakiPrice.Location = new System.Drawing.Point(368, 489);
			this.TakoyakiPrice.Name = "TakoyakiPrice";
			this.TakoyakiPrice.Size = new System.Drawing.Size(37, 13);
			this.TakoyakiPrice.TabIndex = 161;
			this.TakoyakiPrice.Text = "₱  60";
			// 
			// SFhead
			// 
			this.SFhead.Image = ((System.Drawing.Image)(resources.GetObject("SFhead.Image")));
			this.SFhead.Location = new System.Drawing.Point(366, 50);
			this.SFhead.Name = "SFhead";
			this.SFhead.Size = new System.Drawing.Size(630, 111);
			this.SFhead.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.SFhead.TabIndex = 160;
			this.SFhead.TabStop = false;
			// 
			// BigIsawButton
			// 
			this.BigIsawButton.Location = new System.Drawing.Point(908, 514);
			this.BigIsawButton.Name = "BigIsawButton";
			this.BigIsawButton.Size = new System.Drawing.Size(112, 34);
			this.BigIsawButton.TabIndex = 159;
			this.BigIsawButton.Text = "Add To Cart";
			this.BigIsawButton.UseVisualStyleBackColor = true;
			this.BigIsawButton.Click += new System.EventHandler(this.BigIsawButton_Click);
			// 
			// YakitoriButton
			// 
			this.YakitoriButton.Location = new System.Drawing.Point(628, 514);
			this.YakitoriButton.Name = "YakitoriButton";
			this.YakitoriButton.Size = new System.Drawing.Size(112, 34);
			this.YakitoriButton.TabIndex = 158;
			this.YakitoriButton.Text = "Add To Cart";
			this.YakitoriButton.UseVisualStyleBackColor = true;
			this.YakitoriButton.Click += new System.EventHandler(this.YakitoriButton_Click);
			// 
			// TakoyakiButton
			// 
			this.TakoyakiButton.Location = new System.Drawing.Point(335, 514);
			this.TakoyakiButton.Name = "TakoyakiButton";
			this.TakoyakiButton.Size = new System.Drawing.Size(112, 34);
			this.TakoyakiButton.TabIndex = 157;
			this.TakoyakiButton.Text = "Add To Cart";
			this.TakoyakiButton.UseVisualStyleBackColor = true;
			this.TakoyakiButton.Click += new System.EventHandler(this.TakoyakiButton_Click);
			// 
			// BigIsawText
			// 
			this.BigIsawText.AutoSize = true;
			this.BigIsawText.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.BigIsawText.Location = new System.Drawing.Point(864, 411);
			this.BigIsawText.Name = "BigIsawText";
			this.BigIsawText.Size = new System.Drawing.Size(216, 34);
			this.BigIsawText.TabIndex = 156;
			this.BigIsawText.Text = "Grilled-pork intestines marinated\r\n in Special sauce";
			// 
			// YakitoriText
			// 
			this.YakitoriText.AutoSize = true;
			this.YakitoriText.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.YakitoriText.Location = new System.Drawing.Point(573, 406);
			this.YakitoriText.Name = "YakitoriText";
			this.YakitoriText.Size = new System.Drawing.Size(216, 68);
			this.YakitoriText.TabIndex = 155;
			this.YakitoriText.Text = "Japanese skewered mushroom, \r\naparagus, bean sprouts, rolled\r\nover bacon then gri" +
    "lled over \r\ncharcoal fire";
			// 
			// TakoyakiText
			// 
			this.TakoyakiText.AutoSize = true;
			this.TakoyakiText.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.TakoyakiText.Location = new System.Drawing.Point(295, 397);
			this.TakoyakiText.Name = "TakoyakiText";
			this.TakoyakiText.Size = new System.Drawing.Size(208, 68);
			this.TakoyakiText.TabIndex = 154;
			this.TakoyakiText.Text = "Ball-shaped Japanese snack \r\nfilled with diced octopus, \r\ntempura scraps, pickled" +
    " ginger\r\nand green onion";
			// 
			// BigIsawLabel
			// 
			this.BigIsawLabel.AutoSize = true;
			this.BigIsawLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
			this.BigIsawLabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.BigIsawLabel.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.BigIsawLabel.Location = new System.Drawing.Point(1011, 348);
			this.BigIsawLabel.Name = "BigIsawLabel";
			this.BigIsawLabel.Size = new System.Drawing.Size(51, 16);
			this.BigIsawLabel.TabIndex = 153;
			this.BigIsawLabel.Text = "Big Isaw";
			// 
			// YakitoriLabel
			// 
			this.YakitoriLabel.AutoSize = true;
			this.YakitoriLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
			this.YakitoriLabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.YakitoriLabel.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.YakitoriLabel.Location = new System.Drawing.Point(748, 348);
			this.YakitoriLabel.Name = "YakitoriLabel";
			this.YakitoriLabel.Size = new System.Drawing.Size(46, 16);
			this.YakitoriLabel.TabIndex = 152;
			this.YakitoriLabel.Text = "Yakitori";
			// 
			// YakitoriBox
			// 
			this.YakitoriBox.Image = ((System.Drawing.Image)(resources.GetObject("YakitoriBox.Image")));
			this.YakitoriBox.Location = new System.Drawing.Point(574, 212);
			this.YakitoriBox.Name = "YakitoriBox";
			this.YakitoriBox.Size = new System.Drawing.Size(220, 167);
			this.YakitoriBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.YakitoriBox.TabIndex = 151;
			this.YakitoriBox.TabStop = false;
			// 
			// BigIsawBox
			// 
			this.BigIsawBox.Image = ((System.Drawing.Image)(resources.GetObject("BigIsawBox.Image")));
			this.BigIsawBox.Location = new System.Drawing.Point(874, 192);
			this.BigIsawBox.Name = "BigIsawBox";
			this.BigIsawBox.Size = new System.Drawing.Size(188, 187);
			this.BigIsawBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.BigIsawBox.TabIndex = 150;
			this.BigIsawBox.TabStop = false;
			// 
			// TakoyakiLabel
			// 
			this.TakoyakiLabel.AutoSize = true;
			this.TakoyakiLabel.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(224)))), ((int)(((byte)(192)))));
			this.TakoyakiLabel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
			this.TakoyakiLabel.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.TakoyakiLabel.Location = new System.Drawing.Point(426, 348);
			this.TakoyakiLabel.Name = "TakoyakiLabel";
			this.TakoyakiLabel.Size = new System.Drawing.Size(54, 16);
			this.TakoyakiLabel.TabIndex = 149;
			this.TakoyakiLabel.Text = "Takoyaki";
			// 
			// TakoyakiBox
			// 
			this.TakoyakiBox.Image = ((System.Drawing.Image)(resources.GetObject("TakoyakiBox.Image")));
			this.TakoyakiBox.Location = new System.Drawing.Point(298, 192);
			this.TakoyakiBox.Name = "TakoyakiBox";
			this.TakoyakiBox.Size = new System.Drawing.Size(191, 187);
			this.TakoyakiBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
			this.TakoyakiBox.TabIndex = 148;
			this.TakoyakiBox.TabStop = false;
			// 
			// CartBox
			// 
			this.CartBox.Font = new System.Drawing.Font("Century Gothic", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.CartBox.FormattingEnabled = true;
			this.CartBox.ItemHeight = 17;
			this.CartBox.Location = new System.Drawing.Point(396, 83);
			this.CartBox.Name = "CartBox";
			this.CartBox.Size = new System.Drawing.Size(277, 412);
			this.CartBox.TabIndex = 164;
			// 
			// button6
			// 
			this.button6.Location = new System.Drawing.Point(738, 352);
			this.button6.Name = "button6";
			this.button6.Size = new System.Drawing.Size(161, 72);
			this.button6.TabIndex = 165;
			this.button6.Text = "Add More";
			this.button6.UseVisualStyleBackColor = true;
			this.button6.Click += new System.EventHandler(this.button6_Click);
			// 
			// button8
			// 
			this.button8.Location = new System.Drawing.Point(738, 168);
			this.button8.Name = "button8";
			this.button8.Size = new System.Drawing.Size(161, 72);
			this.button8.TabIndex = 166;
			this.button8.Text = "Remove Item";
			this.button8.UseVisualStyleBackColor = true;
			this.button8.Click += new System.EventHandler(this.button8_Click);
			// 
			// button9
			// 
			this.button9.Location = new System.Drawing.Point(738, 258);
			this.button9.Name = "button9";
			this.button9.Size = new System.Drawing.Size(161, 72);
			this.button9.TabIndex = 167;
			this.button9.Text = "Clear All";
			this.button9.UseVisualStyleBackColor = true;
			this.button9.Click += new System.EventHandler(this.button9_Click);
			// 
			// Total
			// 
			this.Total.AutoSize = true;
			this.Total.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Total.Location = new System.Drawing.Point(722, 91);
			this.Total.Name = "Total";
			this.Total.Size = new System.Drawing.Size(91, 22);
			this.Total.TabIndex = 168;
			this.Total.Text = "Subtotal:";
			// 
			// Amount
			// 
			this.Amount.AutoSize = true;
			this.Amount.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.Amount.Location = new System.Drawing.Point(840, 91);
			this.Amount.Name = "Amount";
			this.Amount.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.Amount.Size = new System.Drawing.Size(0, 22);
			this.Amount.TabIndex = 169;
			// 
			// Finalize
			// 
			this.Finalize.Location = new System.Drawing.Point(735, 352);
			this.Finalize.Name = "Finalize";
			this.Finalize.Size = new System.Drawing.Size(161, 72);
			this.Finalize.TabIndex = 170;
			this.Finalize.Text = "Finalize Order";
			this.Finalize.UseVisualStyleBackColor = true;
			this.Finalize.Click += new System.EventHandler(this.Finalize_Click);
			// 
			// ChangeLabel
			// 
			this.ChangeLabel.AutoSize = true;
			this.ChangeLabel.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.ChangeLabel.Location = new System.Drawing.Point(722, 124);
			this.ChangeLabel.Name = "ChangeLabel";
			this.ChangeLabel.Size = new System.Drawing.Size(116, 22);
			this.ChangeLabel.TabIndex = 172;
			this.ChangeLabel.Text = "Change for";
			// 
			// NoteLabel
			// 
			this.NoteLabel.AutoSize = true;
			this.NoteLabel.Font = new System.Drawing.Font("Century Gothic", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.NoteLabel.Location = new System.Drawing.Point(717, 124);
			this.NoteLabel.Name = "NoteLabel";
			this.NoteLabel.Size = new System.Drawing.Size(206, 32);
			this.NoteLabel.TabIndex = 175;
			this.NoteLabel.Text = "EatFresh has a minimum order of 200\r\n                                 *12%VAT exc" +
    "lusive";
			// 
			// textBox1
			// 
			this.textBox1.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.textBox1.Location = new System.Drawing.Point(844, 121);
			this.textBox1.Name = "textBox1";
			this.textBox1.Size = new System.Drawing.Size(61, 31);
			this.textBox1.TabIndex = 176;
			this.textBox1.Text = "0";
			// 
			// label8
			// 
			this.label8.AutoSize = true;
			this.label8.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label8.Location = new System.Drawing.Point(722, 191);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(58, 22);
			this.label8.TabIndex = 177;
			this.label8.Text = "Total:";
			// 
			// label9
			// 
			this.label9.AutoSize = true;
			this.label9.Font = new System.Drawing.Font("Century Gothic", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
			this.label9.Location = new System.Drawing.Point(840, 191);
			this.label9.Name = "label9";
			this.label9.RightToLeft = System.Windows.Forms.RightToLeft.No;
			this.label9.Size = new System.Drawing.Size(65, 22);
			this.label9.TabIndex = 178;
			this.label9.Text = "label6";
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(1089, 613);
			this.Controls.Add(this.button8);
			this.Controls.Add(this.label9);
			this.Controls.Add(this.label8);
			this.Controls.Add(this.CartBox);
			this.Controls.Add(this.Amount);
			this.Controls.Add(this.Total);
			this.Controls.Add(this.button9);
			this.Controls.Add(this.BigIsawPrice);
			this.Controls.Add(this.TakoyakiPrice);
			this.Controls.Add(this.YakitoriButton);
			this.Controls.Add(this.BigIsawText);
			this.Controls.Add(this.YakitoriText);
			this.Controls.Add(this.TakoyakiText);
			this.Controls.Add(this.BigIsawLabel);
			this.Controls.Add(this.YakitoriLabel);
			this.Controls.Add(this.TakoyakiLabel);
			this.Controls.Add(this.TakoyakiBox);
			this.Controls.Add(this.WelcomeText);
			this.Controls.Add(this.StrawberryText);
			this.Controls.Add(this.WGulamanText);
			this.Controls.Add(this.NaiChaText);
			this.Controls.Add(this.BGulamanText);
			this.Controls.Add(this.HKNoodlesPrice);
			this.Controls.Add(this.panel2);
			this.Controls.Add(this.panel1);
			this.Controls.Add(this.strawberryprice);
			this.Controls.Add(this.naichaprice);
			this.Controls.Add(this.naichalabel);
			this.Controls.Add(this.strawberrylabel);
			this.Controls.Add(this.blackgulamanbox);
			this.Controls.Add(this.Gulamanlabel);
			this.Controls.Add(this.CWMushroomButton);
			this.Controls.Add(this.BeefBrisketButton);
			this.Controls.Add(this.CHSausageButton);
			this.Controls.Add(this.BeefBrisketPrice);
			this.Controls.Add(this.CSausageCoLabel);
			this.Controls.Add(this.whitegulamanprice);
			this.Controls.Add(this.WGulamanButton);
			this.Controls.Add(this.blackgulamanprice);
			this.Controls.Add(this.BGulamanButton);
			this.Controls.Add(this.whitegulamanlabel);
			this.Controls.Add(this.CWMushroomLabel);
			this.Controls.Add(this.BeefBrisketLabel);
			this.Controls.Add(this.HKNoodlesButton);
			this.Controls.Add(this.LaksaButton);
			this.Controls.Add(this.BeefNoodlesButton);
			this.Controls.Add(this.LaksaPrice);
			this.Controls.Add(this.BeefNoodlesPrice);
			this.Controls.Add(this.BeefNoodlesLabel);
			this.Controls.Add(this.HKNoodlesLabel);
			this.Controls.Add(this.BeefNoodlesBox);
			this.Controls.Add(this.BeefBrisketText);
			this.Controls.Add(this.CSausageCoBox);
			this.Controls.Add(this.CSausageCoPrice);
			this.Controls.Add(this.CSausageCoButton);
			this.Controls.Add(this.CHSausageLabel);
			this.Controls.Add(this.CHSausageText);
			this.Controls.Add(this.CHSausagePrice);
			this.Controls.Add(this.BeefBrisketBox);
			this.Controls.Add(this.HKNoodlesText);
			this.Controls.Add(this.BeefNoodlesText);
			this.Controls.Add(this.LaksaText);
			this.Controls.Add(this.CWMushroomText);
			this.Controls.Add(this.LaksaLabel);
			this.Controls.Add(this.TakoyakiButton);
			this.Controls.Add(this.YakitoriPrice);
			this.Controls.Add(this.BigIsawButton);
			this.Controls.Add(this.StrawberryButton);
			this.Controls.Add(this.NaiChaButton);
			this.Controls.Add(this.CWMushroomPrice);
			this.Controls.Add(this.BigIsawBox);
			this.Controls.Add(this.strawberrybox);
			this.Controls.Add(this.HKNoodlesBox);
			this.Controls.Add(this.CHSausageBox);
			this.Controls.Add(this.YakitoriBox);
			this.Controls.Add(this.CSausageText);
			this.Controls.Add(this.naichabox);
			this.Controls.Add(this.CWMushroomBox);
			this.Controls.Add(this.NoteLabel);
			this.Controls.Add(this.ChangeLabel);
			this.Controls.Add(this.textBox1);
			this.Controls.Add(this.SFhead);
			this.Controls.Add(this.claypothead);
			this.Controls.Add(this.drinkshead);
			this.Controls.Add(this.NoodlesHead);
			this.Controls.Add(this.Finalize);
			this.Controls.Add(this.whitegulamanbox);
			this.Controls.Add(this.LaksaBox);
			this.Controls.Add(this.WelcomeBox);
			this.Controls.Add(this.button6);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
			this.Name = "Form1";
			this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
			this.Text = "Form1";
			this.panel1.ResumeLayout(false);
			this.panel1.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
			this.panel2.ResumeLayout(false);
			this.panel2.PerformLayout();
			((System.ComponentModel.ISupportInitialize)(this.strawberrybox)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.drinkshead)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.blackgulamanbox)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.whitegulamanbox)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.naichabox)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.claypothead)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.CSausageCoBox)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.CWMushroomBox)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.CHSausageBox)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.BeefBrisketBox)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.WelcomeBox)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.NoodlesHead)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.HKNoodlesBox)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.LaksaBox)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.BeefNoodlesBox)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.SFhead)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.YakitoriBox)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.BigIsawBox)).EndInit();
			((System.ComponentModel.ISupportInitialize)(this.TakoyakiBox)).EndInit();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Button button12;
		private System.Windows.Forms.Button button4;
		private System.Windows.Forms.Button button3;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Button button7;
		private System.Windows.Forms.PictureBox pictureBox1;
		private System.Windows.Forms.Button button5;
		private System.Windows.Forms.Button button2;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.Button button1;
		public System.Windows.Forms.Label Gulamanlabel;
		public System.Windows.Forms.Label naichalabel;
		public System.Windows.Forms.Label strawberrylabel;
		public System.Windows.Forms.Label whitegulamanlabel;
		public System.Windows.Forms.Label strawberryprice;
		public System.Windows.Forms.Label naichaprice;
		public System.Windows.Forms.Label whitegulamanprice;
		public System.Windows.Forms.Label blackgulamanprice;
		public System.Windows.Forms.Button StrawberryButton;
		public System.Windows.Forms.Button WGulamanButton;
		public System.Windows.Forms.Button NaiChaButton;
		public System.Windows.Forms.Button BGulamanButton;
		public System.Windows.Forms.PictureBox strawberrybox;
		public System.Windows.Forms.PictureBox drinkshead;
		public System.Windows.Forms.PictureBox blackgulamanbox;
		public System.Windows.Forms.PictureBox whitegulamanbox;
		public System.Windows.Forms.PictureBox naichabox;
		public System.Windows.Forms.PictureBox claypothead;
		public System.Windows.Forms.PictureBox CSausageCoBox;
		public System.Windows.Forms.PictureBox CWMushroomBox;
		public System.Windows.Forms.PictureBox CHSausageBox;
		public System.Windows.Forms.PictureBox BeefBrisketBox;
		public System.Windows.Forms.Label CSausageCoLabel;
		public System.Windows.Forms.Label CHSausageLabel;
		public System.Windows.Forms.Label CWMushroomLabel;
		public System.Windows.Forms.Label BeefBrisketLabel;
		private System.Windows.Forms.Label WelcomeText;
		private System.Windows.Forms.PictureBox WelcomeBox;
		public System.Windows.Forms.Label CSausageCoPrice;
		public System.Windows.Forms.Label CWMushroomPrice;
		public System.Windows.Forms.Label CHSausagePrice;
		public System.Windows.Forms.Label BeefBrisketPrice;
		public System.Windows.Forms.Button CSausageCoButton;
		public System.Windows.Forms.Button CHSausageButton;
		public System.Windows.Forms.Button BeefBrisketButton;
		public System.Windows.Forms.Button CWMushroomButton;
		public System.Windows.Forms.Label HKNoodlesPrice;
		public System.Windows.Forms.Label LaksaPrice;
		public System.Windows.Forms.Label BeefNoodlesPrice;
		public System.Windows.Forms.PictureBox NoodlesHead;
		public System.Windows.Forms.Label HKNoodlesText;
		public System.Windows.Forms.Label BeefNoodlesText;
		public System.Windows.Forms.Label LaksaText;
		public System.Windows.Forms.Label BeefNoodlesLabel;
		public System.Windows.Forms.Label HKNoodlesLabel;
		public System.Windows.Forms.Label LaksaLabel;
		public System.Windows.Forms.PictureBox HKNoodlesBox;
		public System.Windows.Forms.PictureBox LaksaBox;
		public System.Windows.Forms.PictureBox BeefNoodlesBox;
		public System.Windows.Forms.Button BeefNoodlesButton;
		public System.Windows.Forms.Button LaksaButton;
		public System.Windows.Forms.Button HKNoodlesButton;
		public System.Windows.Forms.Label CSausageText;
		public System.Windows.Forms.Label BeefBrisketText;
		public System.Windows.Forms.Label CHSausageText;
		public System.Windows.Forms.Label CWMushroomText;
		private System.Windows.Forms.Label BGulamanText;
		private System.Windows.Forms.Label NaiChaText;
		private System.Windows.Forms.Label WGulamanText;
		private System.Windows.Forms.Label StrawberryText;
		public System.Windows.Forms.Label BigIsawPrice;
		public System.Windows.Forms.Label YakitoriPrice;
		public System.Windows.Forms.Label TakoyakiPrice;
		public System.Windows.Forms.PictureBox SFhead;
		public System.Windows.Forms.Button BigIsawButton;
		public System.Windows.Forms.Button YakitoriButton;
		public System.Windows.Forms.Button TakoyakiButton;
		public System.Windows.Forms.Label BigIsawText;
		public System.Windows.Forms.Label YakitoriText;
		public System.Windows.Forms.Label TakoyakiText;
		public System.Windows.Forms.Label BigIsawLabel;
		public System.Windows.Forms.Label YakitoriLabel;
		public System.Windows.Forms.PictureBox YakitoriBox;
		public System.Windows.Forms.PictureBox BigIsawBox;
		public System.Windows.Forms.Label TakoyakiLabel;
		public System.Windows.Forms.PictureBox TakoyakiBox;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.ListBox CartBox;
		private System.Windows.Forms.Button button6;
		private System.Windows.Forms.Button button8;
		private System.Windows.Forms.Button button9;
		private System.Windows.Forms.Label Total;
		private System.Windows.Forms.Label Amount;
		private System.Windows.Forms.Button Finalize;
		private System.Windows.Forms.Label ChangeLabel;
		private System.Windows.Forms.Label NoteLabel;
		private System.Windows.Forms.TextBox textBox1;
		private System.Windows.Forms.Label label6;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.Label label9;
	}
}

