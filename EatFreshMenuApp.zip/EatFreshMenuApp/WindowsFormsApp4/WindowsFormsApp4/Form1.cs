﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace WindowsFormsApp4
{
	public partial class Form1 : Form
	{
		
		FoodClass obj = new FoodClass();
	
		public Form1()
		{
			InitializeComponent();
			WelcomeShow();
			DrinksHide();
			ClayPotHide();
			NoodlesHide();
			SFHide();
			CartBox.Hide();
			label4.Text = DateTime.Now.ToLongTimeString();
			label5.Text = DateTime.Now.ToLongDateString();
			CartBoxHide();
			textBox1.Hide();
			ChangeLabel.Hide();
			Finalize.Hide();
			NoteLabel.Hide();
			label8.Hide();

		}

		private void button12_Click(object sender, EventArgs e)
		{
			ClayPotHide();
			DrinksShow();
			WelcomeHide();
			SFHide();
			NoodlesHide();
			CartBoxHide();
			textBox1.Hide();
			ChangeLabel.Hide();
			Finalize.Hide();
			NoteLabel.Hide();
			label8.Hide();
			label9.Hide();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			this.Close();
		}



		private void button7_Click(object sender, EventArgs e)
		{
			WelcomeHide();
			ClayPotShow();
			DrinksHide();
			NoodlesHide();
			SFHide();
			CartBoxHide();
			textBox1.Hide();
			ChangeLabel.Hide();
			Finalize.Hide();
			NoteLabel.Hide();
			label8.Hide();
			label9.Hide();
		}





		private void DrinksShow()
		{
			drinkshead.Show();
			blackgulamanbox.Show();
			blackgulamanprice.Show();
			BGulamanButton.Show();
			Gulamanlabel.Show();
			Gulamanlabel.BringToFront();
			BGulamanText.Show();
			naichabox.Show();
			NaiChaButton.Show();
			naichalabel.Show();
			naichaprice.Show();
			naichalabel.BringToFront();
			NaiChaText.Show();
			WGulamanButton.Show();
			whitegulamanbox.Show();
			whitegulamanprice.Show();
			whitegulamanlabel.Show();
			whitegulamanlabel.BringToFront();
			WGulamanText.Show();
			strawberrybox.Show();
			StrawberryButton.Show();
			strawberrylabel.Show();
			strawberrylabel.BringToFront();
			strawberryprice.Show();
			StrawberryText.Show();
		}
		private void DrinksHide()
		{
			drinkshead.Hide();
			blackgulamanbox.Hide();
			blackgulamanprice.Hide();
			BGulamanButton.Hide();
			Gulamanlabel.Hide();
			BGulamanText.Hide();
			naichabox.Hide();
			NaiChaButton.Hide();
			naichalabel.Hide();
			naichaprice.Hide();
			NaiChaText.Hide();
			WGulamanButton.Hide();
			whitegulamanbox.Hide();
			whitegulamanprice.Hide();
			whitegulamanlabel.Hide();
			WGulamanText.Hide();
			strawberrybox.Hide();
			StrawberryButton.Hide();
			strawberrylabel.Hide();
			strawberryprice.Hide();
			StrawberryText.Hide();



		}

		private void WelcomeShow()
		{
			WelcomeText.Show();
			WelcomeBox.Show();
			WelcomeText.BringToFront();
			
		}
		private void WelcomeHide()
		{
			WelcomeBox.Hide();
			WelcomeText.Hide();
		}
		private void ClayPotShow()
		{
				claypothead.Show();
				CWMushroomBox.Show();
				CWMushroomButton.Show();
				CWMushroomLabel.Show();
				CWMushroomLabel.BringToFront();
				CWMushroomPrice.Show();
				CWMushroomText.Show();
				CHSausageBox.Show();
				CHSausageButton.Show();
				CHSausageLabel.Show();
				CHSausagePrice.Show();
				CHSausageLabel.BringToFront();
				CHSausageText.Show();
				CSausageCoBox.Show();
				CSausageCoButton.Show();
				CSausageCoLabel.Show();
				CSausageCoPrice.Show();
				CSausageCoLabel.BringToFront();
				CSausageText.Show();
				BeefBrisketBox.Show();
				BeefBrisketButton.Show();
				BeefBrisketLabel.Show();
				BeefBrisketPrice.Show();
				BeefBrisketLabel.BringToFront();
				BeefBrisketText.Show();
		}
		private void ClayPotHide()
		{
			claypothead.Hide();
			CWMushroomBox.Hide();
			CWMushroomButton.Hide();
			CWMushroomLabel.Hide();
			CWMushroomPrice.Hide();
			CWMushroomText.Hide();
			CHSausageBox.Hide();
			CHSausageButton.Hide();
			CHSausageLabel.Hide();
			CHSausagePrice.Hide();
			CHSausageText.Hide();
			CSausageCoBox.Hide();
			CSausageCoButton.Hide();
			CSausageCoLabel.Hide();
			CSausageCoPrice.Hide();
			CSausageText.Hide();
			BeefBrisketBox.Hide();
			BeefBrisketButton.Hide();
			BeefBrisketLabel.Hide();
			BeefBrisketPrice.Hide();
			BeefBrisketText.Hide();



		}

		private void button4_Click(object sender, EventArgs e)
		{
			WelcomeHide();
			DrinksHide();
			ClayPotHide();
			NoodlesShow();
			SFHide();
			CartBoxHide();
			textBox1.Hide();
			ChangeLabel.Hide();
			Finalize.Hide();
			NoteLabel.Hide();
			label8.Hide();
			label9.Hide();
		}
		private void NoodlesShow()
		{
			NoodlesHead.Show();
			BeefNoodlesBox.Show();
			BeefNoodlesLabel.Show();
			BeefNoodlesLabel.BringToFront();
			BeefNoodlesButton.Show();
			BeefNoodlesPrice.Show();
			BeefNoodlesText.Show();
			LaksaBox.Show();
			LaksaButton.Show();
			LaksaLabel.Show();
			LaksaPrice.Show();
			LaksaText.Show();
			LaksaLabel.BringToFront();
			HKNoodlesBox.Show();
			HKNoodlesButton.Show();
			HKNoodlesLabel.Show();
			HKNoodlesPrice.Show();
			HKNoodlesText.Show();
			HKNoodlesLabel.BringToFront();
		}
		private void NoodlesHide()
		{
			NoodlesHead.Hide();
			BeefNoodlesBox.Hide();
			BeefNoodlesLabel.Hide();
			BeefNoodlesButton.Hide();
			BeefNoodlesPrice.Hide();
			BeefNoodlesText.Hide();
			LaksaBox.Hide();
			LaksaButton.Hide();
			LaksaLabel.Hide();
			LaksaPrice.Hide();
			LaksaText.Hide();
			HKNoodlesBox.Hide();
			HKNoodlesButton.Hide();
			HKNoodlesLabel.Hide();
			HKNoodlesPrice.Hide();
			HKNoodlesText.Hide();

		}
		private void SFShow()
		{
			SFhead.Show();
			TakoyakiBox.Show();
			TakoyakiButton.Show();
			TakoyakiLabel.Show();
			TakoyakiLabel.BringToFront();
			TakoyakiPrice.Show();
			TakoyakiText.Show();
			YakitoriBox.Show();
			YakitoriButton.Show();
			YakitoriLabel.Show();
			YakitoriPrice.Show();
			YakitoriText.Show();
			YakitoriLabel.BringToFront();
			BigIsawBox.Show();
			BigIsawButton.Show();
			BigIsawLabel.Show();
			BigIsawPrice.Show();
			BigIsawLabel.BringToFront();
			BigIsawText.Show();
		}
		private void SFHide()
		{
			SFhead.Hide();
			TakoyakiBox.Hide();
			TakoyakiButton.Hide();
			TakoyakiLabel.Hide();
			TakoyakiPrice.Hide();
			TakoyakiText.Hide();
			YakitoriBox.Hide();
			YakitoriButton.Hide();
			YakitoriLabel.Hide();
			YakitoriPrice.Hide();
			YakitoriText.Hide();
			BigIsawBox.Hide();
			BigIsawButton.Hide();
			BigIsawLabel.Hide();
			BigIsawPrice.Hide();
			BigIsawText.Hide();
			

		}

		private void button3_Click(object sender, EventArgs e)
		{
			SFShow();
			WelcomeHide();
			DrinksHide();
			ClayPotHide();
			NoodlesHide();
			CartBoxHide();
			textBox1.Hide();
			ChangeLabel.Hide();
			Finalize.Hide();
			NoteLabel.Hide();
			label8.Hide();
			label9.Hide();

		}

		private void CartBoxHide()
		{
			CartBox.Hide();
			button8.Hide();
			button9.Hide();
			button6.Hide();
			Total.Hide();
			Amount.Hide();
			NoteLabel.Hide();
			textBox1.Hide();
			ChangeLabel.Hide();
			Finalize.Hide();
			label8.Hide();
			label9.Hide();
		}

		private void button2_Click(object sender, EventArgs e)
		{
			
			
			if (CartBox.Visible)
			{
				Amount.Text = "₱" + obj.TOTALAMNT_prop.ToString();
				CartBox.Show();
				CartBox.BringToFront();
				button8.Show();
				button9.Show();
				button6.Show();
				label8.Hide();
				label9.Hide();
				Finalize.Hide();


			}
			else
			{
				Amount.Text = "₱" + obj.TOTALAMNT_prop.ToString();
				CartBox.Show();
				CartBox.BringToFront();
				button8.Show();
				button9.Show();
				button6.Show();
				Total.Show();
				Amount.Show();
				ClayPotHide();
				DrinksHide();
				WelcomeHide();
				SFHide();
				NoodlesHide();
				NoteLabel.Show();
				textBox1.Hide();
				ChangeLabel.Hide();
				Finalize.Hide();
				label8.Hide();
				label9.Hide();
				Finalize.Hide();
			}
		}

		private void button6_Click(object sender, EventArgs e)
		{
			if (this.CartBox.SelectedIndex >= 0)
			{
				this.CartBox.Items.Add(this.CartBox.SelectedItem);
				string x = Convert.ToString(this.CartBox.SelectedItem);
				int pricee = Convert.ToInt32(x.Split('₱')[1]);
				obj.TOTALAMNT_prop = obj.TOTALAMNT_prop + (decimal)pricee;
				Amount.Text = "₱" + obj.TOTALAMNT_prop.ToString();
			}
		}

		private void button8_Click(object sender, EventArgs e)
		{
			if (this.CartBox.SelectedIndex >= 0)
			{
				string x = Convert.ToString(this.CartBox.SelectedItem);
				int pricee = Convert.ToInt32(x.Split('₱')[1]);
				obj.TOTALAMNT_prop = obj.TOTALAMNT_prop - (decimal)pricee;
				this.CartBox.Items.Remove(this.CartBox.SelectedItem);
				Amount.Text ="₱"+ obj.TOTALAMNT_prop.ToString();
			}
			
		}

		private void button9_Click(object sender, EventArgs e)
		{
			this.CartBox.Items.Clear();
			obj.TOTALAMNT_prop = 0;
			Amount.Text = "₱"+ 0.ToString();
		}

		private void TakoyakiButton_Click(object sender, EventArgs e)
		{
			CartBox.Items.Add("Takoyaki             \t\t       ₱60");
			obj.TOTALAMNT_prop = obj.TOTALAMNT_prop + obj.StrFoodPrice[0];
			MessageBox.Show("You have added " + obj.StrFoodName[0], "Eat Fresh Hongkong Famous Streetfood");

		}

		private void YakitoriButton_Click(object sender, EventArgs e)
		{
			CartBox.Items.Add("Yakitori            \t\t       ₱120");
			obj.TOTALAMNT_prop = obj.TOTALAMNT_prop + obj.StrFoodPrice[1];
			MessageBox.Show("You have added " + obj.StrFoodName[1], "Eat Fresh Hongkong Famous Streetfood");
			
		}

		private void BigIsawButton_Click(object sender, EventArgs e)
		{
			CartBox.Items.Add("Big Isaw            \t\t       ₱38");
			obj.TOTALAMNT_prop = obj.TOTALAMNT_prop + obj.StrFoodPrice[2];
			MessageBox.Show("You have added " + obj.StrFoodName[2], "Eat Fresh Hongkong Famous Streetfood");
		}

		private void BGulamanButton_Click(object sender, EventArgs e)
		{
			CartBox.Items.Add("Black Gulaman                 \t       ₱60");
			obj.TOTALAMNT_prop = obj.TOTALAMNT_prop + obj.drinksPrice[0];
			MessageBox.Show("You have added " + obj.drinksName[0], "Eat Fresh Hongkong Famous Streetfood");

		}

		private void NaiChaButton_Click(object sender, EventArgs e)
		{
			CartBox.Items.Add("NaiCha             \t\t       ₱70");
			
			obj.TOTALAMNT_prop = obj.TOTALAMNT_prop + obj.drinksPrice[1];
			MessageBox.Show("You have added " + obj.drinksName[1], "Eat Fresh Hongkong Famous Streetfood");

		}

		private void WGulamanButton_Click(object sender, EventArgs e)
		{
			CartBox.Items.Add("WhiteGulaman\t\t       ₱60");
			
			obj.TOTALAMNT_prop = obj.TOTALAMNT_prop + obj.drinksPrice[2];
			MessageBox.Show("You have added " + obj.drinksName[2], "Eat Fresh Hongkong Famous Streetfood");

		}

		private void StrawberryButton_Click(object sender, EventArgs e)
		{
			CartBox.Items.Add("StrawberryShake \t\t       ₱85");
			obj.TOTALAMNT_prop = obj.TOTALAMNT_prop + obj.drinksPrice[3];
			MessageBox.Show("You have added " + obj.drinksName[3], "Eat Fresh Hongkong Famous Streetfood");
		}

		private void BeefNoodlesButton_Click(object sender, EventArgs e)
		{
			CartBox.Items.Add("BeefNoodles         \t \t       ₱145");
			obj.TOTALAMNT_prop = obj.TOTALAMNT_prop + obj.NoodlesPrice[0];
			MessageBox.Show("You have added " + obj.NoodlesName[0], "Eat Fresh Hongkong Famous Streetfood");

		}

		private void LaksaButton_Click(object sender, EventArgs e)
		{
			CartBox.Items.Add("Laksa            \t\t       ₱235");
			obj.TOTALAMNT_prop = obj.TOTALAMNT_prop + obj.NoodlesPrice[1];
			MessageBox.Show("You have added " + obj.NoodlesName[1], "Eat Fresh Hongkong Famous Streetfood");
		}

		private void HKNoodlesButton_Click(object sender, EventArgs e)
		{
			CartBox.Items.Add("HKNoodles           \t\t       ₱65");
			obj.TOTALAMNT_prop = obj.TOTALAMNT_prop + obj.NoodlesPrice[2];
			MessageBox.Show("You have added " + obj.NoodlesName[2], "Eat Fresh Hongkong Famous Streetfood");

		}

		private void CSausageCoButton_Click(object sender, EventArgs e)
		{
			CartBox.Items.Add("Chicken with ChineseSausage      ₱185");
			obj.TOTALAMNT_prop = obj.TOTALAMNT_prop + obj.ClaypotPrice[0];
			MessageBox.Show("You have added " + obj.ClaypotName[0], "Eat Fresh Hongkong Famous Streetfood");

		}

		private void CHSausageButton_Click(object sender, EventArgs e)
		{
			CartBox.Items.Add("Chinese Sausage \t\t       ₱145");
			obj.TOTALAMNT_prop = obj.TOTALAMNT_prop + obj.ClaypotPrice[1];
			MessageBox.Show("You have added " + obj.ClaypotName[1], "Eat Fresh Hongkong Famous Streetfood");
		}

		private void CWMushroomButton_Click(object sender, EventArgs e)
		{
			CartBox.Items.Add("ChickenWithMushroom\t       ₱145");
			obj.TOTALAMNT_prop = obj.TOTALAMNT_prop + obj.ClaypotPrice[2];
			MessageBox.Show("You have added " + obj.ClaypotName[2], "Eat Fresh Hongkong Famous Streetfood");
		}

		private void BeefBrisketButton_Click(object sender, EventArgs e)
		{
			CartBox.Items.Add("BeefBrisket            \t\t       ₱165");
			obj.TOTALAMNT_prop = obj.TOTALAMNT_prop + obj.ClaypotPrice[3];
			MessageBox.Show("You have added " + obj.ClaypotName[3], "Eat Fresh Hongkong Famous Streetfood");

		}

		private void button5_Click(object sender, EventArgs e)
		{
			Amount.Text = "₱" + obj.TOTALAMNT_prop.ToString();
			obj.ComputeTOTAL(obj.TOTALAMNT_prop);
			SFHide();
			WelcomeHide();
			DrinksHide();
			ClayPotHide();
			NoodlesHide();
			CartBoxHide();
			CartBox.Show();
			Total.Show();
			Amount.Show();
			Finalize.Show();
			textBox1.Show();
			ChangeLabel.Show();
			label8.Show();
			label9.Show();
			label9.Text = obj.TOTALTOTAL_prop.ToString();
		}
			

		private void Finalize_Click(object sender, EventArgs e)
		{
			

			if (Convert.ToInt32(textBox1.Text) > obj.TOTALTOTAL_prop)
			{
				obj.ComputeVAT(obj.TOTALAMNT_prop);
				obj.getMoney(textBox1.Text);
				obj.getChange();
				string sPath = "C:\\Users\\marcm\\Desktop\\Receipt"+ DateTime.Now.ToString("yyyyMMdd_hhmm") + ".txt";
				System.IO.StreamWriter SaveFile = new System.IO.StreamWriter(sPath);
				SaveFile.WriteLine("=======================================================");
				SaveFile.WriteLine("        EATFRESH HONGKONG STYLE FAMOUS STREETFOOD");
				SaveFile.WriteLine("   100-A Maria Clara Street, Santo Domingo, Quezon City");
				SaveFile.WriteLine("        Phone Numbers:  02 5168022  &   02 4750789");
				SaveFile.WriteLine("                "+DateTime.Now.ToString());
				SaveFile.WriteLine("=======================================================");
				SaveFile.WriteLine("Orders:");
				foreach (var item in CartBox.Items)
				{
					SaveFile.WriteLine(item.ToString());
				}
				SaveFile.WriteLine("=======================================================");
				SaveFile.WriteLine("SubTotal:\t\t\t\t\u20b1" + obj.TOTALAMNT_prop);
				SaveFile.WriteLine("12% VAT:\t\t\t\t\u20b1" + obj.VATAmount_prop);
				SaveFile.WriteLine("Total:\t\t\t\t\t\u20b1" + obj.TOTALTOTAL_prop);
				SaveFile.WriteLine("Amount Received:\t\t\t\u20b1" + obj.INPUTAMOUNT_prop);
				SaveFile.WriteLine("Change:\t\t\t\t\t\u20b1" + obj.Change_prop);
				SaveFile.WriteLine("======================================================");
				SaveFile.WriteLine("Thank you for patronizing EAT FRESH HONGKONG FAMOUS    ");
				SaveFile.WriteLine("STREETFOOD. Invite your friends and family next time!"); 
				SaveFile.Close();
				MessageBox.Show("Order Accepted!\n Please wait for your food as we cook for your Food!", "Eat Fresh Hongkong Famous Streetfood");
				WelcomeShow();
				this.CartBox.Items.Clear();
				SFHide();
				DrinksHide();
				obj.TOTALAMNT_prop = 0;
				ClayPotHide();
				NoodlesHide();
				CartBoxHide();
				CartBox.Hide();
				Total.Hide();
				Amount.Hide();
				Finalize.Hide();
				textBox1.Hide();
				ChangeLabel.Hide();
				Finalize.Hide();
				label8.Hide();
				label9.Hide();
				System.Diagnostics.Process.Start("notepad.exe", "C:\\Users\\marcm\\Desktop\\Receipt" + DateTime.Now.ToString("yyyyMMdd_hhmm") + ".txt");


			}
			else MessageBox.Show("Amount Invalid");
		}
		

		
	}
}
